import 'react-native-url-polyfill/auto';
import React,{useState} from 'react';
import {Alert,SafeAreaView,ScrollView,StyleSheet,Text,TextInput,TouchableOpacity,View} from 'react-native';
import {createClient} from '@supabase/supabase-js';
const supabase=createClient(process.env.EXPO_PUBLIC_SUPABASE_URL||'https://YOUR-PROJECT.supabase.co',process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY||'YOUR_PUBLISHABLE_OR_ANON_KEY');
const fields=[['customer_name','आपका नाम'],['mobile','मोबाइल नंबर'],['pickup','Pickup स्थान'],['delivery','Delivery स्थान'],['vehicle','कौन-सी गाड़ी चाहिए?'],['weight','सामान का वजन'],['goods','कौन-सा सामान है?'],['budget','आपका बजट (₹)']];
export default function App(){
 const [form,setForm]=useState({}),[busy,setBusy]=useState(false);
 const change=(k,v)=>setForm(o=>({...o,[k]:v}));
 async function submit(){
  if(!form.customer_name?.trim()||!form.mobile?.trim()||!form.pickup?.trim()||!form.delivery?.trim()){Alert.alert('जानकारी अधूरी है','नाम, मोबाइल, Pickup और Delivery भरें।');return;}
  if(!/^[0-9]{10}$/.test(form.mobile.trim())){Alert.alert('मोबाइल नंबर जाँचें','10 अंकों का मोबाइल नंबर डालें।');return;}
  setBusy(true);const payload={...form,budget:form.budget?.trim()?Number(form.budget):null,status:'Pending',booking_id:`YMS-${Date.now()}`};
  const {error}=await supabase.from('Bookings').insert(payload);setBusy(false);
  if(error){Alert.alert('Booking नहीं हुई',error.message);return;}
  Alert.alert('Booking भेज दी गई','YMS Logistics टीम आपसे संपर्क करेगी।');setForm({});
 }
 return <SafeAreaView style={s.safe}><ScrollView contentContainerStyle={s.page}><Text style={s.logo}>YMS LOGISTICS</Text><Text style={s.sub}>Goods Transport Booking</Text><View style={s.card}><Text style={s.heading}>नई गाड़ी बुक करें</Text>{fields.map(([k,label])=><View key={k} style={s.group}><Text style={s.label}>{label}</Text><TextInput style={s.input} value={form[k]||''} onChangeText={v=>change(k,v)} placeholder={label} keyboardType={k==='mobile'||k==='budget'?'numeric':'default'}/></View>)}<TouchableOpacity style={s.button} onPress={submit} disabled={busy}><Text style={s.buttonText}>{busy?'भेज रहे हैं...':'BOOKING SUBMIT करें'}</Text></TouchableOpacity><Text style={s.note}>Submit करने पर हमारी टीम संपर्क करेगी।</Text></View></ScrollView></SafeAreaView>;
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:'#eef3f8'},page:{padding:18,flexGrow:1,justifyContent:'center'},logo:{fontSize:29,fontWeight:'900',color:'#123d68',textAlign:'center',marginTop:18},sub:{textAlign:'center',color:'#64748b',marginBottom:18},card:{backgroundColor:'#fff',padding:20,borderRadius:18,elevation:3},heading:{fontSize:22,fontWeight:'800',color:'#123d68',marginBottom:14},group:{marginBottom:12},label:{fontWeight:'700',color:'#334155',marginBottom:6},input:{borderWidth:1,borderColor:'#cbd5e1',borderRadius:9,padding:12,fontSize:16,backgroundColor:'#fff'},button:{backgroundColor:'#123d68',padding:15,borderRadius:10,alignItems:'center',marginTop:10},buttonText:{color:'#fff',fontWeight:'800'},note:{color:'#64748b',fontSize:12,textAlign:'center',marginTop:12}});
