'use client';
import {useEffect,useState} from 'react';
import {createClient} from '@supabase/supabase-js';
type Booking={id:number;booking_id:string|null;created_at:string;customer_name:string|null;mobile:string|null;pickup:string|null;delivery:string|null;vehicle:string|null;weight:string|null;goods:string|null;budget:number|null;fare:number|null;status:string|null};
const url=process.env.NEXT_PUBLIC_SUPABASE_URL||'',key=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY||'';
const supabase=url&&key?createClient(url,key):null;
export default function Home(){
 const [email,setEmail]=useState(''),[password,setPassword]=useState(''),[session,setSession]=useState(false),[rows,setRows]=useState<Booking[]>([]),[fares,setFares]=useState<Record<number,string>>({}),[busy,setBusy]=useState(false),[error,setError]=useState('');
 useEffect(()=>{if(!supabase)return;supabase.auth.getSession().then(({data})=>setSession(!!data.session));const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setSession(!!s));return()=>subscription.unsubscribe()},[]);
 async function login(e:React.FormEvent){e.preventDefault();if(!supabase)return;setBusy(true);setError('');const {error}=await supabase.auth.signInWithPassword({email:email.trim(),password});setBusy(false);if(error)setError(error.message)}
 async function load(){if(!supabase)return;setBusy(true);setError('');const {data,error}=await supabase.from('Bookings').select('*').order('created_at',{ascending:false});setBusy(false);if(error)setError(error.message);else setRows((data||[]) as Booking[])}
 useEffect(()=>{if(session)load()},[session]);
 async function update(id:number,changes:Partial<Booking>){if(!supabase)return;const {error}=await supabase.from('Bookings').update(changes).eq('id',id);if(error)setError(error.message);else load()}
 async function logout(){await supabase?.auth.signOut();setRows([])}
 if(!url||!key)return <main className="wrap"><h1 className="brand">YMS LOGISTICS</h1><div className="panel">apps/admin/.env.local में Supabase URL और anon/publishable key भरें।</div></main>;
 return <main className="wrap"><header className="row"><div><div className="brand">YMS LOGISTICS</div><div className="muted">Admin Dashboard</div></div>{session&&<button className="btn danger" onClick={logout}>Logout</button>}</header>
 {!session?<form className="panel" onSubmit={login}><h2>Admin Login</h2><label>Email</label><input className="field" type="email" value={email} onChange={e=>setEmail(e.target.value)} required/><label>Password</label><input className="field" type="password" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="btn" disabled={busy}>{busy?'Please wait…':'Login'}</button></form>:
 <section className="panel"><div className="row"><h2>Bookings</h2><span className="pill">Total: {rows.length}</span><button className="btn" onClick={load}>Refresh</button></div>{rows.length===0&&!busy&&<p className="muted">अभी कोई Booking नहीं मिली।</p>}
 {rows.map(b=><article className="booking" key={b.id}><div className="row"><b>{b.booking_id||`#${b.id}`}</b><span className="pill">{b.status||'Pending'}</span></div><div className="grid"><p>Customer: {b.customer_name||'—'}<br/>Mobile: {b.mobile||'—'}</p><p>Pickup: {b.pickup||'—'}<br/>Delivery: {b.delivery||'—'}</p><p>Vehicle: {b.vehicle||'—'}<br/>Goods: {b.goods||'—'}<br/>Weight: {b.weight||'—'}</p><p>Budget: {b.budget??'—'}</p></div><label>Final Fare (₹)</label><input className="field" type="number" value={fares[b.id]??(b.fare==null?'':String(b.fare))} onChange={e=>setFares(o=>({...o,[b.id]:e.target.value}))}/><button className="btn green" onClick={()=>update(b.id,{fare:fares[b.id]===''||fares[b.id]==null?null:Number(fares[b.id]),status:'Accepted'})}>Accept & Save Fare</button><button className="btn danger" onClick={()=>update(b.id,{status:'Rejected'})}>Reject</button></article>)}</section>}{error&&<p className="error">{error}</p>}</main>
}
