import './globals.css';
export const metadata={title:'YMS Logistics Admin',description:'YMS Logistics booking dashboard'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="hi"><body>{children}</body></html>}
